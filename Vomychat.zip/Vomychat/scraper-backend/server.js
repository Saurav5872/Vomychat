const express = require("express");
const cors = require("cors");

const app = express();
const PORT = 3000;

app.use(cors());

// Default route for the root URL
app.get("/", (req, res) => {
    res.send("Welcome to the Scraper API!");
});

// Scrape route
app.get("/scrape", (req, res) => {
    const { url, type } = req.query;

    if (!url || !type) {
        return res.status(400).json({ error: "Missing 'url' or 'type' parameter." });
    }

    res.json({ message: `Scraping ${type} data from ${url}` });
});

app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
