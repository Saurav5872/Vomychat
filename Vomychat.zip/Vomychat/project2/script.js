document.getElementById("scraper-form").addEventListener("submit", async (event) => {
    event.preventDefault();

    const url = document.getElementById("url-input").value;
    const scrapeType = document.getElementById("scrape-type").value;
    const output = document.getElementById("output");

    output.textContent = "Scraping in progress...";

    try {
        // Match the fetch URL to the backend route
        const response = await fetch(`http://localhost:3000/scrape?url=${encodeURIComponent(url)}&type=${scrapeType}`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();

        output.textContent = JSON.stringify(data, null, 2);
    } catch (error) {
        output.textContent = `Error: ${error.message}`;
    }
});
