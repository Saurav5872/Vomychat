// script.js

// Example emails for demo
const emails = [
    { id: 1, sender: "example1@gmail.com", subject: "Meeting Reminder", body: "Don't forget about the meeting at 3 PM." },
    { id: 2, sender: "example2@gmail.com", subject: "Promotional Offer", body: "Get 50% off on your next purchase!" },
    { id: 3, sender: "example3@gmail.com", subject: "Spam Alert", body: "You've won a million dollars!" },
  ];
  
  const emailList = document.getElementById("emails");
  const emailContent = document.getElementById("email-content");
  const replyBox = document.getElementById("reply-box");
  const sendReplyButton = document.getElementById("send-reply");
  
  // Load emails into the list
  function loadEmails() {
    emailList.innerHTML = "";
    emails.forEach((email) => {
      const li = document.createElement("li");
      li.textContent = `${email.sender} - ${email.subject}`;
      li.dataset.id = email.id;
      li.addEventListener("click", () => viewEmail(email.id));
      emailList.appendChild(li);
    });
  }
  
  // View email details
  function viewEmail(id) {
    const email = emails.find((e) => e.id === id);
    if (email) {
      emailContent.innerHTML = `
        <p><strong>From:</strong> ${email.sender}</p>
        <p><strong>Subject:</strong> ${email.subject}</p>
        <p>${email.body}</p>
      `;
      replyBox.value = ""; // Clear reply box
    }
  }
  
  // Handle reply sending
  sendReplyButton.addEventListener("click", () => {
    const reply = replyBox.value.trim();
    if (reply) {
      alert(`Reply sent: ${reply}`);
      replyBox.value = ""; // Clear reply box
    } else {
      alert("Please write a reply before sending.");
    }
  });
  
  // Initialize
  loadEmails();
  